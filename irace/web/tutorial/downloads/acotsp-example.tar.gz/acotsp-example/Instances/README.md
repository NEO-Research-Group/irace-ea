<pre>
Travelling salesman problem (TSP) instances.
There are Random Uniform Euclidean with sizes between 1000 and 3000
cities.
These instances are for all purposes in the public domain.
</pre>
